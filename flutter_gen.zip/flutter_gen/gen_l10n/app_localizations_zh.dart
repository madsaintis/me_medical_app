


import 'app_localizations.dart';

/// The translations for Chinese (`zh`).
class AppLocalizationsZh extends AppLocalizations {
  AppLocalizationsZh([String locale = 'zh']) : super(locale);

  @override
  String get language => '中文';

  @override
  String get login => '登录';

  @override
  String get register => '还没有账号？';

  @override
  String get patientcheck => '查看病历';

  @override
  String get patientInfo => '病人信息';

  @override
  String get medicalIn => '药品库存';

  @override
  String get dashboard => '主界面';

  @override
  String get editprofile => '修改信息';

  @override
  String get personInfo => '个人信息';

  @override
  String get fullName => '姓名';

  @override
  String get email => '电子邮箱';

  @override
  String get phoneNum => '联系电话';

  @override
  String get clinicLoc => '诊所地址';

  @override
  String get changeInfo => '确认更改个人信息';

  @override
  String get addItem => '添加药品';

  @override
  String get addStock => '修改库存';

  @override
  String get itemName => '药物名';

  @override
  String get buyPrice => '进价';

  @override
  String get sellPrice => '售假';

  @override
  String get inStock => '存余';

  @override
  String get pCheck => '病人信息查询';

  @override
  String get pInfo => '病人信息';

  @override
  String get noP => '没有找到查询结果';

  @override
  String get medication => '药物处理';

  @override
  String get mName => '药物';

  @override
  String get quantity => '数量';

  @override
  String get addP => '添加病人';

  @override
  String get checkH => '历史记录';

  @override
  String get description => '描述';

  @override
  String get ccc => '确认游览';

  @override
  String get patientN => '姓名';

  @override
  String get patientI => '身份ID';

  @override
  String get patientB => '出生日期';

  @override
  String get patientG => '性别';

  @override
  String get patientC => '联系电话';

  @override
  String get patientA => '地址';
}

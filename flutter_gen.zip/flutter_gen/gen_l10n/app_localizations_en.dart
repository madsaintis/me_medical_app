


import 'app_localizations.dart';

/// The translations for English (`en`).
class AppLocalizationsEn extends AppLocalizations {
  AppLocalizationsEn([String locale = 'en']) : super(locale);

  @override
  String get language => 'English';

  @override
  String get login => 'Login';

  @override
  String get register => 'Register';

  @override
  String get patientcheck => 'Patient Check up';

  @override
  String get patientInfo => 'Patient Information';

  @override
  String get medicalIn => 'Medical Inventory';

  @override
  String get dashboard => 'Dashboard';

  @override
  String get editprofile => 'Edit Profile';

  @override
  String get personInfo => 'Personal Information';

  @override
  String get fullName => 'Full Name';

  @override
  String get email => 'Email';

  @override
  String get phoneNum => 'Phone Number';

  @override
  String get clinicLoc => 'Clinic Location';

  @override
  String get changeInfo => 'Change Infomation';

  @override
  String get addItem => 'Add Item';

  @override
  String get addStock => 'Add Stock';

  @override
  String get itemName => 'item Name';

  @override
  String get buyPrice => 'Buy Price';

  @override
  String get sellPrice => 'Sell Price';

  @override
  String get inStock => 'In Stock';

  @override
  String get pCheck => 'Patient Check Up';

  @override
  String get pInfo => 'Patient Information';

  @override
  String get noP => 'No Patient found';

  @override
  String get medication => 'Medications';

  @override
  String get mName => 'Medicine Name';

  @override
  String get quantity => 'Quantity';

  @override
  String get addP => 'Add Patient';

  @override
  String get checkH => 'Check History';

  @override
  String get description => 'Description';

  @override
  String get ccc => 'Confirm Check Up';

  @override
  String get patientN => 'Patient Name';

  @override
  String get patientI => 'Patient ID';

  @override
  String get patientB => 'Birth Date';

  @override
  String get patientG => 'Gender';

  @override
  String get patientC => 'Contact Number';

  @override
  String get patientA => 'Address';
}
